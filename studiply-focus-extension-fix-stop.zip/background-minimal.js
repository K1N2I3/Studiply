console.log('Minimal background loaded');
