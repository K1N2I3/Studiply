console.log('Minimal content script loaded');
console.log('Chrome runtime:', !!chrome?.runtime);
