// Popup script for Studiply Focus Mode Extension

document.addEventListener('DOMContentLoaded', () => {
  const statusElement = document.getElementById('status');
  const infoElement = document.getElementById('info');
  const sessionTypeElement = document.getElementById('sessionType');
  const timeRemainingElement = document.getElementById('timeRemaining');
  const sitesBlockedElement = document.getElementById('sitesBlocked');
  const siteListElement = document.getElementById('siteList');
  const actionButton = document.getElementById('actionButton');

  // Check extension status
  chrome.runtime.sendMessage({ action: 'getStatus' }, (response) => {
    if (response) {
      updateUI(response);
    }
  });

  // Update UI based on status
  function updateUI(status) {
    if (status.active) {
      statusElement.textContent = 'Active';
      statusElement.className = 'status active';
      infoElement.style.display = 'block';
      actionButton.style.display = 'block';
      actionButton.textContent = 'Go to Studiply';
      actionButton.onclick = () => {
        chrome.tabs.create({ url: 'https://studiply.it' });
      };

      // Update session info
      if (status.sessionData) {
        sessionTypeElement.textContent = status.sessionData.sessionType || 'Focus Session';
        
        // Calculate time remaining
        const startTime = new Date(status.sessionData.startTime).getTime();
        const now = Date.now();
        const elapsed = now - startTime;
        const totalDuration = (status.sessionData.duration || 25) * 60 * 1000;
        const remaining = Math.max(0, totalDuration - elapsed);
        
        const minutes = Math.floor(remaining / 60000);
        const seconds = Math.floor((remaining % 60000) / 1000);
        timeRemainingElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        
        sitesBlockedElement.textContent = status.blockedSites ? status.blockedSites.length : 0;
        
        // Update blocked sites list
        if (status.blockedSites && status.blockedSites.length > 0) {
          siteListElement.innerHTML = status.blockedSites
            .map(site => `<div class="site-item">${site}</div>`)
            .join('');
        } else {
          siteListElement.innerHTML = '<div class="site-item">No sites blocked</div>';
        }
      }
    } else {
      statusElement.textContent = 'Inactive';
      statusElement.className = 'status inactive';
      infoElement.style.display = 'none';
      actionButton.style.display = 'block';
      actionButton.textContent = 'Go to Studiply';
      actionButton.className = 'button secondary';
      actionButton.onclick = () => {
        chrome.tabs.create({ url: 'https://studiply.it' });
      };
      
      siteListElement.innerHTML = '<div class="site-item">No sites blocked</div>';
    }
  }

  // Update every second when active
  setInterval(() => {
    chrome.runtime.sendMessage({ action: 'getStatus' }, (response) => {
      if (response && response.active) {
        updateUI(response);
      }
    });
  }, 1000);
});
